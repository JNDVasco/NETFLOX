create procedure aluguer(dataaluguer integer, datafimaluguer integer, precoaluguercents integer, idartigo integer, idpessoa integer)
    language plpgsql
as
$$
declare
    saldoCliente int;

BEGIN
    SELECT saldo
    INTO saldoCliente
    FROM cliente
    WHERE pessoa_id_pessoa = idPessoa;

    IF saldoCliente >= precoAluguerCents THEN
        INSERT INTO aluguer(preco, artigos_id_art, cliente_pessoa_id_pessoa, data, data_validade)
        VALUES (precoAluguerCents, idArtigo, idPessoa, dataAluguer, dataFimAluguer);
        UPDATE cliente SET saldo = saldoCliente - precoaluguercents WHERE pessoa_id_pessoa = idpessoa;
    ELSE
        RAISE EXCEPTION 'Saldo insuficiente';
        RETURN;
    END IF;
END;
$$;

alter procedure aluguer(integer, integer, integer, integer, integer) owner to lbkoexwzuhsloo;

